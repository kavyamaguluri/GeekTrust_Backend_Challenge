package com.geektrust.backend;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.*;

public class TrainTest {

    @Test
    public void testGetBogiesBeyondHYB_AllBogiesBeyondHYB() {
        Train train = new Train("TRAIN_A", "SLM BLR KRN");

        Map<String, Integer> stationDistancesFromHYB = new HashMap<>();
        stationDistancesFromHYB.put("HYB", 0);
        stationDistancesFromHYB.put("SLM", 350);
        stationDistancesFromHYB.put("BLR", 550);
        stationDistancesFromHYB.put("KRN", 900);

        List<String> expected = Arrays.asList("SLM", "BLR", "KRN");
        List<String> actual = train.getBogiesBeyondHYB(stationDistancesFromHYB);

        assertEquals(expected, actual);
    }

    @Test
    public void testGetBogiesBeyondHYB_SomeBogiesBeyondHYB() {
        Train train = new Train("TRAIN_A", "HYB SLM KRN");

        Map<String, Integer> stationDistancesFromHYB = new HashMap<>();
        stationDistancesFromHYB.put("HYB", 0);
        stationDistancesFromHYB.put("SLM", 350);
        stationDistancesFromHYB.put("KRN", 900);

        List<String> expected = Arrays.asList("SLM", "KRN");
        List<String> actual = train.getBogiesBeyondHYB(stationDistancesFromHYB);

        assertEquals(expected, actual);
    }

    @Test
    public void testGetBogiesBeyondHYB_NoBogiesBeyondHYB() {
        Train train = new Train("TRAIN_A", "HYB");

        Map<String, Integer> stationDistancesFromHYB = new HashMap<>();
        stationDistancesFromHYB.put("HYB", 0);

        List<String> expected = new ArrayList<>();
        List<String> actual = train.getBogiesBeyondHYB(stationDistancesFromHYB);

        assertEquals(expected, actual);
    }

    @Test
    public void testGetBogiesBeyondHYB_EmptyBogies() {
        Train train = new Train("TRAIN_A", "");

        Map<String, Integer> stationDistancesFromHYB = new HashMap<>();
        stationDistancesFromHYB.put("HYB", 0);

        List<String> expected = new ArrayList<>();
        List<String> actual = train.getBogiesBeyondHYB(stationDistancesFromHYB);

        assertEquals(expected, actual);
    }
}



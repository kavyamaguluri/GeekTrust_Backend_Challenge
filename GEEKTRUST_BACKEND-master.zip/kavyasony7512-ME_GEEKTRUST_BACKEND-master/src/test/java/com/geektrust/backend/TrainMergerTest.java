package com.geektrust.backend;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.*;

public class TrainMergerTest {

    @Test
    public void testGetStationDistancesFromHYB() {
        TrainMerger trainMerger = new TrainMerger();
        Map<String, Integer> stationDistances = trainMerger.getStationDistancesFromHYB();

        assertEquals(0, stationDistances.get("HYB").intValue());
        assertEquals(350, stationDistances.get("SLM").intValue());
        assertEquals(550, stationDistances.get("BLR").intValue());
        assertEquals(4700, stationDistances.get("GHY").intValue());
    }


    @Test
    public void testMergeTrains_OneTrainWithBogies() {
        TrainMerger trainMerger = new TrainMerger();
        Map<String, Integer> stationDistancesFromHYB = trainMerger.getStationDistancesFromHYB();

        List<String> bogiesA = Arrays.asList("SLM", "BLR", "KRN");
        List<String> bogiesB = new ArrayList<>();

        List<String> expected = Arrays.asList("KRN", "BLR", "SLM");
        List<String> actual = trainMerger.mergeTrains(bogiesA, bogiesB, stationDistancesFromHYB);

        assertEquals(expected, actual);
    }

    @Test
    public void testMergeTrains_BothTrainsEmpty() {
        TrainMerger trainMerger = new TrainMerger();
        Map<String, Integer> stationDistancesFromHYB = trainMerger.getStationDistancesFromHYB();

        List<String> bogiesA = new ArrayList<>();
        List<String> bogiesB = new ArrayList<>();

        List<String> expected = new ArrayList<>();
        List<String> actual = trainMerger.mergeTrains(bogiesA, bogiesB, stationDistancesFromHYB);

        assertEquals(expected, actual);
    }

    @Test
    public void testMergeTrains_SameStationsDifferentTrains() {
        TrainMerger trainMerger = new TrainMerger();
        Map<String, Integer> stationDistancesFromHYB = trainMerger.getStationDistancesFromHYB();

        List<String> bogiesA = Arrays.asList("SLM", "BLR", "KRN");
        List<String> bogiesB = Arrays.asList("SLM", "BLR", "KRN");

        List<String> expected = Arrays.asList("KRN", "KRN", "BLR", "BLR", "SLM", "SLM");
        List<String> actual = trainMerger.mergeTrains(bogiesA, bogiesB, stationDistancesFromHYB);

        assertEquals(expected, actual);
    }
}



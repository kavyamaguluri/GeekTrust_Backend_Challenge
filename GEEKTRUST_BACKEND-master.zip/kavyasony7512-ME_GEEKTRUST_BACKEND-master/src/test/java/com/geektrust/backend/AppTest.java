package com.geektrust.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class AppTest {

    public void applicationIntegrationTestSampleInput1() {
        String expectedOutput =
                "ARRIVAL TRAIN_A ENGINE SLM BLR KRN\n" + "ARRIVAL TRAIN_B ENGINE NGP ITJ BPL\n"
                        + "DEPARTURE TRAIN_AB ENGINE ENGINE BPL ITJ NGP KRN BLR SLM\n";

        try (PrintStream out = new PrintStream(new FileOutputStream("output.txt"))) {
            System.setOut(out);
            App.main(new String[] {"TRAIN_A ENGINE SLM BLR KRN", "TRAIN_B ENGINE NGP ITJ BPL"});
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        String actualOutput = "";
        try {
            actualOutput = new String(Files.readAllBytes(Paths.get("output.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }

        assertEquals(expectedOutput.trim(), actualOutput.trim());
    }

}



package com.geektrust.backend;

import java.util.*;

public class TrainMerger {

    public Map<String, Integer> getStationDistancesFromHYB() {
        Map<String, Integer> stationDistancesFromHYB = new HashMap<>();
        stationDistancesFromHYB.put("HYB", 0);
        stationDistancesFromHYB.put("SLM", 350);
        stationDistancesFromHYB.put("BLR", 550);
        stationDistancesFromHYB.put("KRN", 900);
        stationDistancesFromHYB.put("NGP", 1600);
        stationDistancesFromHYB.put("ITJ", 1900);
        stationDistancesFromHYB.put("BPL", 2000);
        stationDistancesFromHYB.put("AGA", 2500);
        stationDistancesFromHYB.put("NDL", 2700);
        stationDistancesFromHYB.put("NJP", 4200);
        stationDistancesFromHYB.put("GHY", 4700);
        stationDistancesFromHYB.put("SRR", 300);
        stationDistancesFromHYB.put("MAO", 1000);
        stationDistancesFromHYB.put("PNE", 1400);
        stationDistancesFromHYB.put("PTA", 3800);

        return stationDistancesFromHYB;
    }

    public List<String> mergeTrains(List<String> bogiesA, List<String> bogiesB,
            Map<String, Integer> stationDistancesFromHYB) {

        List<String> mergedBogies = new ArrayList<>();
        mergedBogies.addAll(bogiesA);
        mergedBogies.addAll(bogiesB);

        mergedBogies.sort((a, b) -> {
            int distanceA = stationDistancesFromHYB.getOrDefault(a, 0);
            int distanceB = stationDistancesFromHYB.getOrDefault(b, 0);
            return Integer.compare(distanceB, distanceA);
        });

        return mergedBogies;
    }
}



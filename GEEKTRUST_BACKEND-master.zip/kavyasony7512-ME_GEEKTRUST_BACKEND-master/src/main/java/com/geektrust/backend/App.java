package com.geektrust.backend;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.*;

public class App {
    public static void main(String[] args) {
        try (PrintStream out = new PrintStream(new FileOutputStream("output.txt"))) {
            System.setOut(out);

            TrainMerger trainMerger = new TrainMerger();

            String trainAInput = args[0];
            String trainBInput = args[1];

            Train trainA = new Train("TRAIN_A", trainAInput.substring(9));
            Train trainB = new Train("TRAIN_B", trainBInput.substring(9));

            Map<String, Integer> stationDistancesFromHYB = trainMerger.getStationDistancesFromHYB();

            List<String> bogiesA = trainA.getBogiesBeyondHYB(stationDistancesFromHYB);
            List<String> bogiesB = trainB.getBogiesBeyondHYB(stationDistancesFromHYB);

            System.out.println("ARRIVAL TRAIN_A ENGINE " + String.join(" ", bogiesA));
            System.out.println("ARRIVAL TRAIN_B ENGINE " + String.join(" ", bogiesB));

            List<String> mergedBogies =
                    trainMerger.mergeTrains(bogiesA, bogiesB, stationDistancesFromHYB);
            System.out
                    .println("DEPARTURE TRAIN_AB ENGINE ENGINE " + String.join(" ", mergedBogies));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}



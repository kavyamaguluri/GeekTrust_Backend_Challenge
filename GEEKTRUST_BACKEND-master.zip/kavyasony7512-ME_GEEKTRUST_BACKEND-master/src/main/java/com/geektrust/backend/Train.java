package com.geektrust.backend;

import java.util.*;

public class Train {
    private String trainName;
    private List<String> bogies;

    public Train(String trainName, String bogies) {
        this.trainName = trainName;
        this.bogies = Arrays.asList(bogies.split(" "));
    }

    public List<String> getBogiesBeyondHYB(Map<String, Integer> stationDistancesFromHYB) {
        List<String> bogiesBeyondHYB = new ArrayList<>();
        for (String bogie : bogies) {
            if (stationDistancesFromHYB.containsKey(bogie)
                    && stationDistancesFromHYB.get(bogie) > 0) {
                bogiesBeyondHYB.add(bogie);
            }
        }
        return bogiesBeyondHYB;
    }
}

